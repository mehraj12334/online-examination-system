package com.project.examportalbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamPortalBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
